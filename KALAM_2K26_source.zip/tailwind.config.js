/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: 'var(--color-navy)', 'navy-deep': 'var(--color-navy-deep)',
        burgundy: 'var(--color-burgundy)', 'burgundy-dark': 'var(--color-burgundy-dark)',
        gold: 'var(--color-gold)', emerald: 'var(--color-emerald)', indigo: 'var(--color-indigo)',
        page: 'var(--color-page)', ink: 'var(--color-ink)', muted: 'var(--color-muted)',
        line: 'var(--color-line)'
      },
      fontFamily: { sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'sans-serif'] },
      boxShadow: { soft: 'var(--shadow-soft)', raised: 'var(--shadow-raised)' },
      borderRadius: { card: 'var(--radius-card)', panel: 'var(--radius-panel)' },
      transitionDuration: { fast: '140ms', standard: '220ms' }
    }
  },
  plugins: []
};
