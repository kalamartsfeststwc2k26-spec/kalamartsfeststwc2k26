import test from 'node:test';
import assert from 'node:assert/strict';
import { mutationError } from '../src/lib/adminMutation.js';

test('zero-row RLS-filtered edits and deletes cannot be reported as success', () => {
  assert.match(mutationError({ data: [], error: null }, 'update'), /No record was updated/);
  assert.match(mutationError({ data: [], error: null }, 'delete'), /No record was deleted/);
  assert.equal(mutationError({ data: [{ id: 'one' }], error: null }, 'delete'), '');
  assert.match(mutationError({ data: null, error: { message: 'RLS denied' } }, 'update'), /RLS denied/);
});
