import test from 'node:test';
import assert from 'node:assert/strict';
import { eventStatus, sortEvents, eventSchedule } from '../src/lib/eventUtils.js';

const now = Date.parse('2026-10-29T10:00:00Z');
const event = (start_time, end_time) => ({ id: 'test', name: 'Test', start_time, end_time });
test('missing, invalid, or reversed schedule is TBA rather than a false status', () => {
  assert.equal(eventStatus(event(null, null), now), 'Schedule TBA');
  assert.equal(eventStatus(event('2026-10-29T09:00:00Z', null), now), 'Schedule TBA');
  assert.equal(eventStatus(event(null, '2026-10-29T12:00:00Z'), now), 'Schedule TBA');
  assert.equal(eventStatus(event('invalid', '2026-10-29T12:00:00Z'), now), 'Schedule TBA');
  assert.equal(eventStatus(event('2026-10-29T12:00:00Z', '2026-10-29T11:00:00Z'), now), 'Schedule TBA');
  assert.equal(eventSchedule(event(null, null)), 'Schedule TBA');
});
test('status correctly compares both valid endpoints', () => {
  assert.equal(eventStatus(event('2026-10-29T11:00:00Z', '2026-10-29T12:00:00Z'), now), 'Upcoming');
  assert.equal(eventStatus(event('2026-10-29T09:00:00Z', '2026-10-29T11:00:00Z'), now), 'Live');
  assert.equal(eventStatus(event('2026-10-29T08:00:00Z', '2026-10-29T10:00:00Z'), now), 'Completed');
});
test('sorts by start time ascending with unscheduled entries last', () => {
  assert.deepEqual(sortEvents([event(null, null), { ...event('2026-10-29T12:00:00Z','2026-10-29T13:00:00Z'), id: 'later' }, { ...event('2026-10-29T09:00:00Z','2026-10-29T10:00:00Z'), id: 'first' }]).map(e => e.id), ['first','later','test']);
});
