import test from 'node:test';
import assert from 'node:assert/strict';
import { rankHomeResults } from '../src/lib/homeRanking.js';

test('home standings show shared rank for equal published points', () => {
  const results = [
    { team_id: '1', points: 10 }, { team_id: '2', points: 10 },
    { team_id: '3', points: 5 },
  ];
  const names = new Map([['1', 'KALIDOS'], ['2', 'KALORA'], ['3', 'KOSMORA']]);
  assert.deepEqual(rankHomeResults(results, 'team_id', 'points', names).map(item => item.rank), [1, 1, 3]);
});

test('approved placement-count rule resolves an equal total without a colour-only cue', () => {
  const names = new Map([['1', 'KALIDOS'], ['2', 'KALORA']]);
  const results = [{ team_id: '1', points: 10, placement: 1 }, { team_id: '2', points: 10, placement: 2 }];
  const rules = [{ priority: 0, placement: 1, direction: 'desc' }];
  assert.deepEqual(rankHomeResults(results, 'team_id', 'points', names, 5, rules).map(item => item.rank), [1, 2]);
});
test('homepage includes team-only penalties in net standings without altering earned results', () => {
  const names = new Map([['a', 'Alpha'], ['b', 'Beta']]);
  const rows = rankHomeResults([{ team_id: 'a', points: 2 }], 'team_id', 'points', names, 5, [], [
    { team_id: 'a', deduction_points: 4 }, { team_id: 'b', deduction_points: 1 },
  ]);
  assert.deepEqual(rows.map(row => [row.name, row.points, row.deductionPoints, row.rank]), [
    ['Beta', -1, 1, 1], ['Alpha', -2, 4, 2],
  ]);
});
