import test from 'node:test';
import assert from 'node:assert/strict';
import { groupSchedule } from '../src/lib/schedule.js';

const event = (id, day_label, start_time, end_time) => ({id, name:id, day_label, start_time, end_time});
test('groups by day label and orders by start; incomplete schedules go to TBA', () => {
  const groups = groupSchedule([
    event('later','Day 2','2026-11-02T10:00:00Z','2026-11-02T11:00:00Z'),
    event('missing end','Day 1','2026-11-01T09:00:00Z',null),
    event('early','Day 1','2026-11-01T08:00:00Z','2026-11-01T09:00:00Z'),
    event('no day',null,'2026-11-01T10:00:00Z','2026-11-01T11:00:00Z'),
  ]);
  assert.deepEqual(groups.map(group => group.label), ['Day 1','Day 2','Schedule TBA']);
  assert.deepEqual(groups[2].events.map(row => row.id), ['missing end','no day']);
});
