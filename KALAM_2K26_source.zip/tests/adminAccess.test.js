import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveAdminAccess } from '../src/lib/adminAccess.js';

function client({ user = { id: 'admin' }, authError, profile, profileError, team, teamError } = {}) {
  return {
    auth: { getUser: async () => ({ data: { user }, error: authError }) },
    from: table => ({ select: () => ({ eq: () => ({ maybeSingle: async () => table === 'profiles' ? { data: profile, error: profileError } : { data: team, error: teamError } }) }) }),
  };
}
test('Super Admin with an active database profile receives all-management access', async () => {
  const result = await resolveAdminAccess(client({ profile: { id: 'admin', role: 'super_admin', team_id: null, active: true } }));
  assert.equal(result.status, 'ready'); assert.equal(result.profile.role, 'super_admin');
});
test('Group Admin requires an existing assigned team, not just a claimed role or ID', async () => {
  const profile = { id: 'admin', role: 'group_admin', team_id: 'team-a', active: true };
  assert.equal((await resolveAdminAccess(client({ profile, team: { id: 'team-a', name: 'Team A' } }))).status, 'ready');
  assert.equal((await resolveAdminAccess(client({ profile, team: null }))).status, 'denied');
  assert.equal((await resolveAdminAccess(client({ profile: { ...profile, team_id: null } }))).status, 'denied');
  assert.equal((await resolveAdminAccess(client({ profile, teamError: new Error('Team lookup failed') }))).status, 'error');
});
test('No-admin, inactive, inconsistent and signed-out users are denied', async () => {
  for (const options of [
    { user: null }, { profile: null },
    { profile: { id: 'admin', role: 'viewer', active: true } },
    { profile: { id: 'admin', role: 'super_admin', active: false } },
    { profile: { id: 'someone-else', role: 'super_admin', active: true } },
    { profile: { id: 'admin', role: 'super_admin', team_id: 'team-a', active: true } },
  ]) assert.equal((await resolveAdminAccess(client(options))).status, 'denied');
});
test('Auth and profile query failures are errors, not a grant or a false no-admin decision', async () => {
  assert.equal((await resolveAdminAccess(null)).status, 'error');
  assert.equal((await resolveAdminAccess(client({ authError: new Error('Session expired') }))).status, 'error');
  assert.equal((await resolveAdminAccess(client({ profileError: new Error('Database unavailable') }))).status, 'error');
});
