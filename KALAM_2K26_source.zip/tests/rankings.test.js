import test from 'node:test';
import assert from 'node:assert/strict';
import { makeIndividualStandings, makeTeamStandings } from '../src/lib/rankings.js';

const teams = [{id:'b',name:'Beta'}, {id:'a',name:'Alpha'}, {id:'c',name:'Gamma'}];
const results = [
  {id:'1',team_id:'a',student_id:'s1',student_name:'Asha',team_name:'Alpha',points:'10.00',placement:1,division:'Mahdhiyya'},
  {id:'2',team_id:'b',student_id:'s2',student_name:'Bina',team_name:'Beta',points:'10.00',placement:2,division:'Mahdhiyya'},
  {id:'3',team_id:'c',student_id:'s3',student_name:'Cora',team_name:'Gamma',points:'3.50',placement:3,division:'Mahdhiyya'},
];
test('equal scores share first place; display order alone does not break ties', () => {
  assert.deepEqual(makeTeamStandings(teams, results).map(x => [x.name, x.rank, x.tied]), [['Alpha',1,true],['Beta',1,true],['Gamma',3,false]]);
  assert.deepEqual(makeIndividualStandings(results).map(x => [x.name, x.rank]), [['Asha',1],['Bina',1],['Cora',3]]);
});
test('approved configured placement-count rule resolves equal points', () => {
  const ranked = makeTeamStandings(teams, results, [{placement:1,direction:'desc'}]);
  assert.deepEqual(ranked.map(x => [x.name,x.rank,x.tied]), [['Alpha',1,false],['Beta',2,false],['Gamma',3,false]]);
});
test('all published results belong to the sole Mahdhiyya division', () => {
  assert.deepEqual(makeTeamStandings(teams, results).map(x => [x.name,x.points]), [['Alpha',10],['Beta',10],['Gamma',3.5]]);
});
test('team deductions reduce net points and may go below zero without touching individual ranks', () => {
  const penalties = [{ team_id: 'a', deduction_points: '3.00' }, { team_id: 'c', deduction_points: '5.00' }];
  const ranked = makeTeamStandings(teams, results, [], penalties);
  assert.deepEqual(ranked.map(x => [x.name, x.points, x.earnedPoints, x.deductionPoints]), [
    ['Beta', 10, 10, 0], ['Alpha', 7, 10, 3], ['Gamma', -1.5, 3.5, 5],
  ]);
  assert.deepEqual(makeIndividualStandings(results).map(x => x.points), [10, 10, 3.5]);
});
