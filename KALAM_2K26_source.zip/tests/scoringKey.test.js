import test from 'node:test';
import assert from 'node:assert/strict';
import { eventScoringKey } from '../src/lib/scoringKey.js';

test('programme type and General A/B determine scoring key without a division or grade', () => {
  assert.equal(eventScoringKey({ competition_type: 'On-stage' }), 'On-stage');
  assert.equal(eventScoringKey({ competition_type: 'Non-stage' }), 'Non-stage');
  assert.equal(eventScoringKey({ competition_type: 'General', scoring_category: 'A' }), 'General A');
  assert.equal(eventScoringKey({ competition_type: 'General', scoring_category: 'B' }), 'General B');
  assert.equal(eventScoringKey({ competition_type: 'General', scoring_category: null }), null);
});

test('ATTC uses its stage format for points, not its category as a division', () => {
  assert.equal(eventScoringKey({ competition_type: 'ATTC', stage_type: 'On-stage' }), 'On-stage');
  assert.equal(eventScoringKey({ competition_type: 'ATTC', stage_type: 'Non-stage' }), 'Non-stage');
  assert.equal(eventScoringKey({ competition_type: 'ATTC' }), null);
});
