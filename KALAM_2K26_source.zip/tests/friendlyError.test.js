import test from 'node:test';
import assert from 'node:assert/strict';
import { friendlyQueryError } from '../src/lib/friendlyError.js';

test('public query errors do not print raw database internals', () => {
  assert.match(friendlyQueryError({ code: '42501', message: 'permission denied for relation students' }), /Access/);
  assert.doesNotMatch(friendlyQueryError({ message: 'relation private_students does not exist' }, 'results'), /private_students/);
});
