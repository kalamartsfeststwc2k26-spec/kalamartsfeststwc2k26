import test from 'node:test';
import assert from 'node:assert/strict';
import { getTimeline } from '../src/lib/timeline.js';

const fields = { startsAt: 'start_time', endsAt: 'end_time' };
const now = Date.parse('2026-10-29T10:00:00Z');
test('homepage never treats a partially scheduled event as live or upcoming', () => {
  const rows = [
    { id: 'no-start', start_time: null, end_time: '2026-10-29T11:00:00Z' },
    { id: 'no-end', start_time: '2026-10-29T09:00:00Z', end_time: null },
    { id: 'reversed', start_time: '2026-10-29T11:00:00Z', end_time: '2026-10-29T10:00:00Z' },
    { id: 'live', start_time: '2026-10-29T09:00:00Z', end_time: '2026-10-29T11:00:00Z' },
    { id: 'next', start_time: '2026-10-29T12:00:00Z', end_time: '2026-10-29T13:00:00Z' },
  ];
  const timeline = getTimeline(rows, fields, now);
  assert.deepEqual(timeline.live.map(row => row.id), ['live']);
  assert.deepEqual(timeline.next.map(row => row.id), ['next']);
  assert.deepEqual(timeline.tba.map(row => row.id), ['no-start', 'no-end', 'reversed']);
});
