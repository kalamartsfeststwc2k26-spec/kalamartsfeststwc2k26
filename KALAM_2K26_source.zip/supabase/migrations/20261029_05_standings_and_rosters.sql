-- Optional public identity fields; no images or student records are seeded.
alter table public.teams add column logo_url text;
alter table public.students add column roll_number text;
alter table public.students add column photo_url text;
create index students_team_name_idx on public.students (team_id,name);

-- Deliberate narrow public roster, not anonymous access to the base students table.
create view public.public_team_roster with (security_barrier = true) as
  select s.id as student_id, s.team_id, s.name as student_name,
    s.roll_number, s.photo_url, s.division
  from public.students s join public.teams t on t.id = s.team_id;
revoke all on public.public_team_roster from public;
grant select on public.public_team_roster to anon, authenticated;

-- Special titles are optional published awards, independent from points scoring.
create table public.special_titles (
  id uuid primary key default gen_random_uuid(),
  title_type text not null check (length(btrim(title_type)) > 0),
  award_title text not null check (length(btrim(award_title)) > 0),
  recipient_student_id uuid references public.students(id) on delete restrict,
  recipient_team_id uuid references public.teams(id) on delete restrict,
  division text check (division in ('Mahdhiyya','ATTC')),
  is_published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  constraint one_title_recipient check ((recipient_student_id is null) <> (recipient_team_id is null)),
  constraint published_title_has_time check (not is_published or published_at is not null)
);
create index titles_public_idx on public.special_titles (title_type,published_at desc) where is_published;
alter table public.special_titles enable row level security;
create policy special_titles_public_read on public.special_titles for select to anon,authenticated using (is_published or public.is_super_admin());
create policy special_titles_super_write on public.special_titles for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.special_titles from anon, authenticated;
grant select on public.special_titles to anon, authenticated;
grant insert,update,delete on public.special_titles to authenticated;

-- Public reader receives only the displayed award and recipient name, not student details.
create view public.public_special_titles with (security_barrier = true) as
  select st.id, st.title_type, st.award_title, st.division, st.published_at,
    coalesce(s.name,t.name) as recipient_name,
    case when s.id is not null then 'Individual' else 'Team' end as recipient_kind
  from public.special_titles st
  left join public.students s on s.id = st.recipient_student_id
  left join public.teams t on t.id = st.recipient_team_id
  where st.is_published;
revoke all on public.public_special_titles from public;
grant select on public.public_special_titles to anon,authenticated;

-- Postgres can append columns to an existing view without changing the old projections.
create or replace view public.public_published_results with (security_barrier = true) as
  select r.id, r.event_id, e.name as event_name, r.team_id, t.name as team_name,
    r.student_id, s.name as student_name, r.placement, r.grade, r.points,
    r.published_at, r.status,
    e.division, e.competition_type, e.scoring_category, e.item_category
  from public.results r join public.events e on e.id = r.event_id
  left join public.teams t on t.id = r.team_id
  left join public.students s on s.id = r.student_id
  where r.status = 'published' and r.published_at is not null and e.is_published;
revoke all on public.public_published_results from public;
grant select on public.public_published_results to anon,authenticated;
