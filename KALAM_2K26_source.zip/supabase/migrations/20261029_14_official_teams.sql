-- Official team names supplied by the organiser on 2026-10-29. All caps as requested.
insert into public.teams (name) values ('KALIDOS'), ('KALORA'), ('KOSMORA')
on conflict (name) do nothing;
