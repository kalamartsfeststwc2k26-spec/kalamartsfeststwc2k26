-- ATTC membership is an eligibility credential, not a Group Admin-editable detail.
-- Group Admins may create Mahdhiyya students (is_attc defaults false) but
-- only a Super Admin or trusted service-side context may grant/revoke ATTC.
create function public.guard_attc_membership() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if auth.uid() is not null and not public.is_super_admin() then
    if (tg_op = 'INSERT' and new.is_attc) or
       (tg_op = 'UPDATE' and new.is_attc is distinct from old.is_attc) then
      raise exception 'Only a Super Admin may verify or change ATTC-category membership' using errcode = '42501';
    end if;
  end if;
  return new;
end;
$$;
create trigger students_attc_assignment_guard before insert or update of is_attc on public.students
  for each row execute function public.guard_attc_membership();
revoke all on function public.guard_attc_membership() from public, anon, authenticated;
