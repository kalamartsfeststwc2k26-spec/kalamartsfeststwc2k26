-- Temporary controlled manual scoring while the organiser's separate A/B/C point-category mapping is unspecified.
-- No calculated status or value is asserted. The existing audit trigger captures every reason and value change.
alter table public.results add column manual_points_reason text not null
  check (length(btrim(manual_points_reason)) >= 10);
