-- Super Admin-assigned team minus marks are separate from nonnegative event results.
-- Reasons and actor metadata stay private; the public sees only aggregate deductions.
create table public.team_penalties (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete restrict,
  points numeric(10,2) not null check (points > 0),
  reason text not null check (length(btrim(reason)) >= 10),
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index team_penalties_team_idx on public.team_penalties(team_id);
alter table public.team_penalties enable row level security;
create policy team_penalties_super_all on public.team_penalties for all to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.team_penalties from anon,authenticated;
grant select,insert,update,delete on public.team_penalties to authenticated;
create function public.protect_team_penalty_metadata() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
  if not public.is_super_admin() then raise exception 'Super Admin access required' using errcode='42501'; end if;
  if tg_op='INSERT' then
    new.created_by:=auth.uid();
    new.created_at:=now();
  else
    new.created_by:=old.created_by;
    new.created_at:=old.created_at;
  end if;
  return new;
end;
$$;
create trigger team_penalties_actor before insert or update on public.team_penalties for each row execute function public.protect_team_penalty_metadata();
revoke all on function public.protect_team_penalty_metadata() from public,anon,authenticated;
create trigger audit_team_penalties after insert or update or delete on public.team_penalties for each row execute function public.audit_managed_change();
create view public.public_team_penalty_totals with (security_barrier=true) as
  select team_id, sum(points)::numeric(12,2) as deduction_points, count(*)::integer as deduction_count
  from public.team_penalties group by team_id;
revoke all on public.public_team_penalty_totals from public;
grant select on public.public_team_penalty_totals to anon,authenticated;
