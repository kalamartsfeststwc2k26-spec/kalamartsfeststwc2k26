-- Editor-managed public regulations. Point-category mapping is deliberately NOT assumed here.
create table public.rules_content (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(btrim(title)) > 0),
  body text not null check (length(btrim(body)) > 0),
  display_order integer not null default 0,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.rules_content enable row level security;
create policy rules_content_public_read on public.rules_content for select to anon, authenticated using (is_published or public.is_super_admin());
create policy rules_content_super_write on public.rules_content for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.rules_content from anon, authenticated;
grant select on public.rules_content to anon, authenticated;
grant insert, update, delete on public.rules_content to authenticated;
create trigger audit_rules_content after insert or update or delete on public.rules_content for each row execute function public.audit_managed_change();

-- Exact organiser-supplied regulations, including the repeated പ്രതിഭകൾ material and original General B 15-10-7 schedule.
insert into public.rules_content (title, body, display_order, is_published) values
('പൊതു നിയമങ്ങൾ', $rules$
മൂന്ന് ഗ്രൂപ്പുകൾ തമ്മിലായിരിക്കും മത്സരം നടക്കുക.
ഓരോ ടീമിലെയും എല്ലാ അംഗങ്ങളും മത്സരത്തിൽ പങ്കെടുക്കണം. പങ്കെടുക്കാത്ത അംഗങ്ങളുടെ എണ്ണത്തിനനുസരിച്ച് മൈനസ് പോയിന്റ് ഉണ്ടായിരിക്കും.
ഒരു പരിപാടിക്ക് ഓരോ ഗ്രൂപ്പിൽ നിന്നും 3 അംഗങ്ങളുടെ പങ്കാളിത്തം ഉണ്ടായിരിക്കേണ്ടതാണ്.
ഒരു വിദ്യാർത്ഥിനിക്ക് മിനിമം 3 off stage, 3 on stage, 4 general മത്സരങ്ങൾക്ക് പങ്കെടുക്കാം.
മുകളിൽ പറയപ്പെട്ട നിയമങ്ങൾ പാലിക്കാത്ത പക്ഷം 3 മാർക്ക് മൈനസ് പോയിന്റ് ഉണ്ടായിരിക്കുന്നതാണ്.
Individual items - ന് 5-3-1, General items-ന് category 'A' ക്ക് 20-15-10, category 'B' ക്ക് 15-10-7 എന്നിങ്ങനെയായിരിക്കും പോയിന്റ് നിർണയിക്കപ്പെടുന്നത്.
Teaching, still Model, working model, chart making എന്നീ മത്സരങ്ങൾ ATTC വിദ്യാർത്ഥിനികൾക്ക് മാത്രമായിരിക്കും.
പേര് നൽകിയ പരിപാടികളിൽ പങ്കെടുക്കാത്ത പക്ഷം individual 3, General 5 എന്നിങ്ങനെ മൈനസ് പോയിന്റ് ഉണ്ടായിരിക്കുന്നതാണ്.
A, B, C ഗ്രേഡുകൾക്ക് യഥാക്രമം 5, 3, 1 എന്നിങ്ങനെ പോയിന്റുകൾ നൽകപ്പെടുന്നതാണ്.
ടീം മാനേജർമാർക്ക് ഒരു ഓൺസ്റ്റേജ്, ഒരു ഓഫ് സ്റ്റേജ്, ഒരു ജനറൽ പ്രോഗ്രാമുകളിൽ പങ്കെടുക്കാം.
ഓൺസ്റ്റേജ്, ഓഫ്‌സ്റ്റേജ്, ജനറൽ ഇനങ്ങളിൽ ഏറ്റവും കൂടുതൽ പോയിന്റ് കരസ്ഥമാക്കുന്ന ആളെയാണ് കലാപ്രതിഭയായി തിരഞ്ഞെടുക്കുന്നത്.
വ്യക്തിഗത പോയിന്റ് ലഭിക്കുന്ന മത്സരങ്ങളിൽ നിന്നും ഏറ്റവും കൂടുതൽ പോയിന്റ് ലഭിക്കുന്ന മത്സരാർത്ഥിയെ സർഗ്ഗപ്രതിഭയായി തിരഞ്ഞെടുക്കും.
സർഗ്ഗപ്രതിഭ പട്ടത്തിൽ രണ്ടു പേർ തുല്യ പോയിന്റിന് അർഹരായാൽ ഏറ്റവും കൂടുതൽ ഫസ്റ്റ് ലഭിച്ച മത്സരാർത്ഥിയെ പരിഗണിക്കുന്നതാണ്.
മത്സരത്തിന് 5 മിനിറ്റ് മുമ്പ് മത്സരാർത്ഥികൾ മത്സര സ്ഥലത്ത് ഹാജരാകണം.
മത്സരത്തിന് ഒരു മണിക്കൂർ മുമ്പ് മത്സരാർത്ഥികളെ മാറ്റാവുന്നതാണ്. അതിനുശേഷം 50 രൂപ ഫൈനോടുകൂടി മത്സരാർത്ഥികളെ മാറ്റാവുന്നതാണ്. മത്സരത്തിന് 10 മിനിറ്റ് മുമ്പ് വരെ മത്സരാർത്ഥികളെ മാറ്റാൻ അവസരമുണ്ടാകുകയുള്ളൂ, അതിനു ശേഷം സാധിക്കുകയില്ല.
റീപ്ലേസ്മെന്റ് ഫോം മുഖേന മാത്രമേ മത്സരാർത്ഥിയെ മാറ്റാൻ സാധിക്കുകയുള്ളൂ.
കോളേജ് കലോത്സവത്തിന്റെ നടത്തിപ്പ് സംബന്ധിച്ച് അന്തിമ തീരുമാനം Fest കമ്മിറ്റിയിൽ നിക്ഷിപ്തമായിരിക്കും.
ഗ്രൂപ്പ് കൺവീനർ മുഖേന മാത്രമേ പരാതി സ്വീകരിക്കുകയുള്ളൂ, അല്ലാത്തപക്ഷം സ്വീകരിക്കുന്നതല്ല.
$rules$, 1, true),
('അപ്പീൽ', $rules$
ജഡ്ജ്മെന്റ് ഷീറ്റ്, ടാബുലേഷൻ ഷീറ്റ് എന്നിവയിലെ സൂക്ഷ്മ പരിശോധനയ്ക്ക് മാത്രമേ അപ്പീൽ അനുവദിക്കുകയുള്ളൂ.
ഫലപ്രഖ്യാപനത്തിനു ശേഷം ഫലത്തിൽ പരാതിയുള്ളവർ 30 മിനിറ്റിനുള്ളിൽ അപ്പീൽ ഫോം (100 രൂപ) മുഖേന പരാതി സമർപ്പിക്കേണ്ടതാണ്.
$rules$, 2, true),
('പ്രതിഭകൾ', $rules$
ഓൺസ്റ്റേജ്, ഓഫ്‌സ്റ്റേജ്, ജനറൽ ഇനങ്ങളിൽ ഏറ്റവും കൂടുതൽ പോയിന്റ് കരസ്തമാക്കുന്ന ആളെയാണ് കലാപ്രതിഭ.
വ്യക്തിഗത പോയിന്റ് ലഭിക്കുന്ന മത്സരങ്ങളിൽ നിന്നും ഏറ്റവും കൂടുതൽ പോയിന്റ് ലഭിക്കുന്ന മത്സരാർത്ഥിയെ സർഗ്ഗപ്രതിഭയായി തിരഞ്ഞെടുക്കും.
സർഗ്ഗപ്രതിഭ പട്ടത്തിൽ രണ്ടു പേർ തുല്യ പോയിന്റിന് അർഹരായാൽ ഏറ്റവും കൂടുതൽ ഫസ്റ്റ് ലഭിച്ച മത്സരാർത്ഥിയെ പരിഗണിക്കുന്നതാണ്.
$rules$, 3, true);
