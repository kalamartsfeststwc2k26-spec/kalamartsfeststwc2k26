-- Append-only audit for managed records; profile changes are logged by the server Edge Function.
create table public.admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid,
  action text not null,
  entity_table text not null,
  entity_id uuid,
  before_data jsonb,
  after_data jsonb,
  occurred_at timestamptz not null default now()
);
create index admin_audit_recent on public.admin_audit_log (occurred_at desc);
alter table public.admin_audit_log enable row level security;
create policy audit_super_read on public.admin_audit_log for select to authenticated using (public.is_super_admin());
revoke all on public.admin_audit_log from anon,authenticated;
grant select on public.admin_audit_log to authenticated;
create function public.audit_managed_change() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
  insert into public.admin_audit_log(actor_id,action,entity_table,entity_id,before_data,after_data)
  values(auth.uid(),tg_op,tg_table_name,case when tg_op='DELETE' then old.id else new.id end,
    case when tg_op='INSERT' then null else to_jsonb(old) end,
    case when tg_op='DELETE' then null else to_jsonb(new) end);
  return case when tg_op='DELETE' then old else new end;
end;
$$;
create trigger audit_teams after insert or update or delete on public.teams for each row execute function public.audit_managed_change();
create trigger audit_students after insert or update or delete on public.students for each row execute function public.audit_managed_change();
create trigger audit_events after insert or update or delete on public.events for each row execute function public.audit_managed_change();
create trigger audit_registrations after insert or update or delete on public.registrations for each row execute function public.audit_managed_change();
create trigger audit_results after insert or update or delete on public.results for each row execute function public.audit_managed_change();
create trigger audit_announcements after insert or update or delete on public.announcements for each row execute function public.audit_managed_change();
create trigger audit_committee after insert or update or delete on public.committee_members for each row execute function public.audit_managed_change();
create trigger audit_titles after insert or update or delete on public.special_titles for each row execute function public.audit_managed_change();
create trigger audit_tie_breakers after insert or update or delete on public.standing_tie_breakers for each row execute function public.audit_managed_change();
revoke all on function public.audit_managed_change() from public,anon,authenticated;

-- Group Admin ownership is resolved on the server, never accepted as a client team ID.
create function public.add_student_to_my_team(p_name text,p_roll_number text default null,p_photo_url text default null)
returns uuid language plpgsql security definer set search_path=public,pg_temp as $$
declare assigned_team uuid; new_id uuid;
begin
  assigned_team:=public.group_admin_team_id();
  if assigned_team is null then raise exception 'Active Group Admin assignment required' using errcode='42501'; end if;
  if p_name is null or length(btrim(p_name))=0 then raise exception 'Student name is required' using errcode='23514'; end if;
  insert into public.students(name,team_id,roll_number,photo_url,is_attc)
  values(btrim(p_name),assigned_team,nullif(btrim(p_roll_number),''),nullif(btrim(p_photo_url),''),false)
  returning id into new_id;
  return new_id;
end;
$$;
revoke all on function public.add_student_to_my_team(text,text,text) from public,anon;
grant execute on function public.add_student_to_my_team(text,text,text) to authenticated;
