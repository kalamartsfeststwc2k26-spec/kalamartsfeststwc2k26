-- Record privileged operator bootstrap without attributing it to a browser session.
insert into public.admin_audit_log (actor_id, action, entity_table, entity_id, after_data)
select null, 'SUPER_ADMIN_BOOTSTRAP', 'profiles', p.id, to_jsonb(p)
from public.profiles p join auth.users u on u.id = p.id
where lower(u.email) = 'kalamartsfeststwc2k26@gmail.com'
  and p.role = 'super_admin' and p.active
  and not exists (select 1 from public.admin_audit_log a
    where a.action = 'SUPER_ADMIN_BOOTSTRAP' and a.entity_id = p.id);
