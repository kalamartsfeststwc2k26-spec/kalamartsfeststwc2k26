-- Group Admins may correct registrations only when both the old and new student belong to their verified team.
-- Super Admin's existing update policy remains in effect; eligibility trigger checks ATTC and publication.
create policy registrations_group_update on public.registrations for update to authenticated
  using (exists (select 1 from public.students s where s.id = student_id and s.team_id = public.group_admin_team_id()))
  with check (exists (select 1 from public.students s where s.id = student_id and s.team_id = public.group_admin_team_id()));
