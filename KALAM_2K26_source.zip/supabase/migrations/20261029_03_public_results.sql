-- Public names are restricted to published results and only the fields the UI needs.
create view public.public_published_results with (security_barrier = true) as
  select r.id, r.event_id, e.name as event_name, r.team_id, t.name as team_name,
    r.student_id, s.name as student_name, r.placement, r.grade, r.points,
    r.published_at, r.status
  from public.results r join public.events e on e.id = r.event_id
  left join public.teams t on t.id = r.team_id
  left join public.students s on s.id = r.student_id
  where r.status = 'published' and r.published_at is not null and e.is_published;
revoke all on public.public_published_results from public;
grant select on public.public_published_results to anon, authenticated;
