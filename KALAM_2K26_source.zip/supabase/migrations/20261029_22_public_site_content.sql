-- Editorial contact/about fields were previously fixed frontend copy. Store approved values
-- as published content so revisiting those public routes reflects Super Admin edits.
create table public.site_content (
  id uuid primary key default gen_random_uuid(),
  page text not null check (page in ('about','contact')),
  content_key text not null,
  content text not null check (length(btrim(content)) > 0),
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  unique(page,content_key),
  constraint site_content_key_check check (
    (page='about' and content_key='intro') or
    (page='contact' and content_key in ('college','address','desk','phone','hours','audit_email'))
  )
);
alter table public.site_content enable row level security;
create policy site_content_public_read on public.site_content for select to anon,authenticated using (is_published or public.is_super_admin());
create policy site_content_super_write on public.site_content for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.site_content from anon,authenticated;
grant select on public.site_content to anon,authenticated;
grant insert,update,delete on public.site_content to authenticated;
create trigger audit_site_content after insert or update or delete on public.site_content for each row execute function public.audit_managed_change();
insert into public.site_content(page,content_key,content,is_published) values
('about','intro','KALAM Arts Fest 2K26 is organised by the ASAAS Students Union at Shihab Thangal Women’s College (STWC), Chundampatta, Palakkad. It celebrates the creativity and expression of the college’s student community.',true),
('contact','college','Shihab Thangal Women’s College (STWC)',true),
('contact','address','Chundampatta, Palakkad, Kerala – 679337',true),
('contact','desk','Stage Managers Desk',true),
('contact','phone','+91 9656747437',true),
('contact','hours','8:00 AM–10:00 PM',true),
('contact','audit_email','stwomenscollege@gmail.com',true);
