-- Authoritative matrix confirmed by organiser: General B stays 15/10/7 as in published regulations.
-- No point-category C: C is solely a result grade. ATTC stays a restricted competition type,
-- with optional stage_type to choose the On-stage/Non-stage placement schedule.
create table public.category_points (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('On-stage','Non-stage','General A','General B')),
  position integer not null check (position between 1 and 3),
  points numeric(10,2) not null check (points >= 0),
  created_at timestamptz not null default now(),
  unique(category, position)
);
create table public.grade_points (
  id uuid primary key default gen_random_uuid(),
  grade text not null check (grade in ('A','B','C')),
  points numeric(10,2) not null check (points >= 0),
  created_at timestamptz not null default now(),
  unique(grade)
);
alter table public.category_points enable row level security;
alter table public.grade_points enable row level security;
create policy category_points_public_read on public.category_points for select to anon,authenticated using (true);
create policy category_points_super_write on public.category_points for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
create policy grade_points_public_read on public.grade_points for select to anon,authenticated using (true);
create policy grade_points_super_write on public.grade_points for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.category_points,public.grade_points from anon,authenticated;
grant select on public.category_points,public.grade_points to anon,authenticated;
grant insert,update,delete on public.category_points,public.grade_points to authenticated;
create trigger audit_category_points after insert or update or delete on public.category_points for each row execute function public.audit_managed_change();
create trigger audit_grade_points after insert or update or delete on public.grade_points for each row execute function public.audit_managed_change();
insert into public.category_points(category,position,points) values
('On-stage',1,5),('On-stage',2,3),('On-stage',3,1),
('Non-stage',1,5),('Non-stage',2,3),('Non-stage',3,1),
('General A',1,20),('General A',2,15),('General A',3,10),
('General B',1,15),('General B',2,10),('General B',3,7);
insert into public.grade_points(grade,points) values ('A',5),('B',3),('C',1);
-- Previously manual-only, now the same explanation field records either an approved
-- manual fallback reason or an actual server-computed component breakdown.
alter table public.results rename column manual_points_reason to points_explanation;
alter table public.results add column points_source text not null default 'manual'
  check (points_source in ('manual','calculated'));
