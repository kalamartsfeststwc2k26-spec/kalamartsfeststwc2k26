-- Super Admin-only calculator. The category is a scoring key, never a division or grade.
create function public.calculate_result_points(p_category text, p_position integer, p_grade text default null)
returns jsonb language plpgsql stable security definer set search_path=public,pg_temp as $$
declare placement_points numeric(10,2); awarded_grade_points numeric(10,2):=0;
begin
  if not public.is_super_admin() then raise exception 'Super Admin access required' using errcode='42501'; end if;
  if p_category is null or p_category not in ('On-stage','Non-stage','General A','General B') then
    raise exception 'The event scoring category is missing or unsupported; use approved manual entry' using errcode='23514';
  end if;
  if p_position is null or p_position not between 1 and 3 then
    raise exception 'Only first, second and third place have configured points; use approved manual entry' using errcode='23514';
  end if;
  select points into placement_points from public.category_points where category=p_category and position=p_position;
  if placement_points is null then raise exception 'Placement point rule is missing; use approved manual entry' using errcode='23514'; end if;
  if p_grade is not null then
    select points into awarded_grade_points from public.grade_points where grade=p_grade;
    if awarded_grade_points is null then raise exception 'Grade point rule is missing; use approved manual entry' using errcode='23514'; end if;
  end if;
  return jsonb_build_object('category',p_category,'position',p_position,'grade',p_grade,
    'category_points',placement_points,'grade_points',awarded_grade_points,'total',placement_points+awarded_grade_points);
end;
$$;
revoke all on function public.calculate_result_points(text,integer,text) from public,anon;
grant execute on function public.calculate_result_points(text,integer,text) to authenticated;

-- Always derive the category from the trusted event. Never trust a browser-supplied scoring key
-- or browser-supplied computed total; even a direct REST write is recomputed before persistence.
create function public.enforce_calculated_result_points() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare event_type text; general_category text; event_stage text; scoring_key text; breakdown jsonb;
begin
  if new.points_source <> 'calculated' then return new; end if;
  if not public.is_super_admin() then raise exception 'Super Admin access required' using errcode='42501'; end if;
  select competition_type,scoring_category,stage_type into event_type,general_category,event_stage
    from public.events where id=new.event_id;
  if not found then raise exception 'Event not found' using errcode='23503'; end if;
  if event_type='General' then
    if general_category not in ('A','B') or general_category is null then
      raise exception 'General event has no valid A/B scoring category; use approved manual entry' using errcode='23514';
    end if;
    scoring_key:='General '||general_category;
  elsif event_type='ATTC' then
    if event_stage is null then raise exception 'ATTC event needs an On-stage or Non-stage stage format for automatic scoring' using errcode='23514'; end if;
    scoring_key:=event_stage;
  elsif event_type in ('On-stage','Non-stage') then scoring_key:=event_type;
  else raise exception 'Unknown competition category' using errcode='23514'; end if;
  if new.grade is not null and new.student_id is null then
    raise exception 'Grade points are only configured for individual students; use approved manual entry' using errcode='23514';
  end if;
  breakdown:=public.calculate_result_points(scoring_key,new.placement,new.grade);
  new.points:=(breakdown->>'total')::numeric;
  new.points_explanation:=format('RPC calculated: %s place %s = %s; grade %s = %s; total = %s',
    scoring_key,new.placement,breakdown->>'category_points',coalesce(new.grade,'none'),
    breakdown->>'grade_points',breakdown->>'total');
  return new;
end;
$$;
create trigger results_calculated_points before insert or update of points_source,event_id,placement,grade,points,student_id,points_explanation
  on public.results for each row execute function public.enforce_calculated_result_points();
revoke all on function public.enforce_calculated_result_points() from public,anon,authenticated;
