-- KALAM 2K26: initial server-side model. No seed records or invented scoring matrix.
create table public.teams (
  id uuid primary key default gen_random_uuid(),
  name text not null unique check (length(btrim(name)) > 0),
  created_at timestamptz not null default now()
);
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('super_admin','group_admin')),
  team_id uuid references public.teams(id) on delete restrict,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint group_admin_has_team check ((role = 'group_admin' and team_id is not null) or (role = 'super_admin' and team_id is null))
);
create table public.students (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) > 0),
  division text not null check (division in ('Mahdhiyya','ATTC')),
  team_id uuid not null references public.teams(id) on delete restrict,
  created_at timestamptz not null default now()
);
create table public.events (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) > 0),
  item_category text not null check (length(btrim(item_category)) > 0),
  description text,
  venue text,
  start_time timestamptz,
  end_time timestamptz,
  day_label text,
  division text not null check (division in ('Mahdhiyya','ATTC')),
  competition_type text not null check (competition_type in ('On-stage','Non-stage','General','ATTC')),
  scoring_category text check (scoring_category in ('A','B')),
  min_participants integer not null default 1 check (min_participants > 0),
  max_participants integer check (max_participants is null or max_participants >= min_participants),
  duration_minutes integer check (duration_minutes is null or duration_minutes > 0),
  judging_criteria text,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  constraint chronological_event check (start_time is null or end_time is null or end_time > start_time)
);
create table public.registrations (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (event_id,student_id)
);
create table public.results (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete restrict,
  student_id uuid references public.students(id) on delete restrict,
  team_id uuid references public.teams(id) on delete restrict,
  placement integer check (placement is null or placement > 0),
  grade text,
  points numeric(10,2) not null default 0 check (points >= 0),
  status text not null default 'draft' check (status in ('draft','published','retracted')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  constraint has_result_owner check (student_id is not null or team_id is not null),
  constraint published_has_time check (status <> 'published' or published_at is not null)
);
create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null check (length(btrim(title)) > 0),
  body text not null,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.committee_members (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) > 0),
  role_title text not null,
  sort_order integer not null default 0,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
create index events_public_schedule_idx on public.events (start_time,id) where is_published;
create index events_public_filters_idx on public.events (division,competition_type,day_label) where is_published;
create index registrations_event_idx on public.registrations (event_id);
create index students_team_idx on public.students (team_id);
create index results_published_idx on public.results (published_at desc,id) where status = 'published';
create index results_team_idx on public.results (team_id) where status = 'published';
create index results_student_idx on public.results (student_id) where status = 'published';
create index announcements_public_idx on public.announcements (created_at desc) where is_published;
alter table public.teams enable row level security;
alter table public.profiles enable row level security;
alter table public.students enable row level security;
alter table public.events enable row level security;
alter table public.registrations enable row level security;
alter table public.results enable row level security;
alter table public.announcements enable row level security;
alter table public.committee_members enable row level security;
