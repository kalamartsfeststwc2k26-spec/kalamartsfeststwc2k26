-- A result must also belong to a currently published event to be publicly readable.
drop policy results_public_read on public.results;
create policy results_public_read on public.results for select to anon, authenticated
  using ((status = 'published' and published_at is not null and
    exists (select 1 from public.events e where e.id = event_id and e.is_published))
    or public.is_super_admin());
