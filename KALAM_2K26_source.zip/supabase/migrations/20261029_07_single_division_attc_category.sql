-- Corrected organiser model: Mahdhiyya is the sole division.
-- ATTC is a membership category within Mahdhiyya, NOT a second division.
-- Compatible with legacy rows if applying to another environment.
alter table public.students add column is_attc boolean not null default false;
drop trigger students_preserve_eligibility on public.students;
alter table public.events drop constraint events_division_check;
alter table public.students drop constraint students_division_check;
alter table public.special_titles drop constraint special_titles_division_check;
alter table public.standing_tie_breakers drop constraint standing_tie_breakers_division_check;
update public.students set is_attc = true, division = 'Mahdhiyya' where division = 'ATTC';
update public.events set division = 'Mahdhiyya' where division = 'ATTC';
update public.special_titles set division = 'Mahdhiyya' where division = 'ATTC';
update public.standing_tie_breakers set division = 'Mahdhiyya' where division = 'ATTC';
alter table public.events alter column division set default 'Mahdhiyya';
alter table public.students alter column division set default 'Mahdhiyya';
alter table public.events add constraint events_division_check check (division = 'Mahdhiyya');
alter table public.students add constraint students_division_check check (division = 'Mahdhiyya');
alter table public.special_titles add constraint special_titles_division_check check (division is null or division = 'Mahdhiyya');
alter table public.standing_tie_breakers add constraint standing_tie_breakers_division_check check (division is null or division = 'Mahdhiyya');

create or replace function public.enforce_registration_eligibility() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare student_is_attc boolean; event_type text; event_published boolean;
begin
  select is_attc into student_is_attc from public.students where id = new.student_id;
  select competition_type, is_published into event_type, event_published from public.events where id = new.event_id;
  if student_is_attc is null or event_type is null then raise exception 'Student or event not found' using errcode = '23503'; end if;
  if not event_published then raise exception 'Registration is unavailable until the event is published' using errcode = '23514'; end if;
  if event_type = 'ATTC' and not student_is_attc then
    raise exception 'Only ATTC-category students may register for ATTC-category programmes' using errcode = '23514';
  end if;
  new.created_by := auth.uid();
  return new;
end;
$$;
create or replace function public.protect_attc_registrations() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if not new.is_attc and exists (select 1 from public.registrations r join public.events e on e.id=r.event_id where r.student_id=new.id and e.competition_type='ATTC') then
    raise exception 'Cannot remove ATTC membership: student has an ATTC-category registration' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger students_preserve_eligibility before update of is_attc on public.students for each row execute function public.protect_attc_registrations();
create or replace function public.protect_event_eligibility() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.competition_type = 'ATTC' and exists (select 1 from public.registrations r join public.students s on s.id=r.student_id where r.event_id=new.id and not s.is_attc) then
    raise exception 'Cannot change to ATTC competition type while non-ATTC students are registered' using errcode = '23514';
  end if;
  return new;
end;
$$;

-- Append membership to the narrow public roster without granting base students access.
create or replace view public.public_team_roster with (security_barrier = true) as
  select s.id as student_id, s.team_id, s.name as student_name,
    s.roll_number, s.photo_url, s.division, s.is_attc
  from public.students s join public.teams t on t.id = s.team_id;
revoke all on public.public_team_roster from public;
grant select on public.public_team_roster to anon, authenticated;
