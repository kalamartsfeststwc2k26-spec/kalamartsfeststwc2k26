-- Optional stage format: ATTC is still the competition category, not a division.
-- Useful when an ATTC programme is held on-stage or off-stage.
alter table public.events add column stage_type text
  check (stage_type is null or stage_type in ('On-stage','Non-stage'));
alter table public.events add constraint event_stage_consistency check (
  stage_type is null or competition_type not in ('On-stage','Non-stage') or stage_type = competition_type
);
