-- Optional public committee identity/contact fields; existing published-only RLS applies.
alter table public.committee_members add column photo_url text;
alter table public.committee_members add column contact_phone text;
alter table public.committee_members add column contact_email text;
-- Append the team name to the narrow public roster; keep students table private.
create or replace view public.public_team_roster with (security_barrier = true) as
  select s.id as student_id, s.team_id, s.name as student_name,
    s.roll_number, s.photo_url, s.division, s.is_attc, t.name as team_name
  from public.students s join public.teams t on t.id = s.team_id;
revoke all on public.public_team_roster from public;
grant select on public.public_team_roster to anon, authenticated;
