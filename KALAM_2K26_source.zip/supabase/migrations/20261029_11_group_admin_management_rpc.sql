-- Server-checked, atomic profile mutations and audit records.
create function public.create_group_admin_profile(p_user_id uuid,p_team_id uuid)
returns public.profiles language plpgsql security definer set search_path=public,pg_temp as $$
declare created public.profiles;
begin
  if not public.is_super_admin() then raise exception 'Super Admin access required' using errcode='42501'; end if;
  if not exists(select 1 from public.teams where id=p_team_id) then raise exception 'Team not found' using errcode='23503'; end if;
  insert into public.profiles(id,role,team_id,active) values(p_user_id,'group_admin',p_team_id,true) returning * into created;
  insert into public.admin_audit_log(actor_id,action,entity_table,entity_id,after_data)
  values(auth.uid(),'GROUP_ADMIN_CREATE','profiles',p_user_id,to_jsonb(created));
  return created;
end;
$$;
create function public.update_group_admin_profile(p_user_id uuid,p_action text,p_team_id uuid default null)
returns public.profiles language plpgsql security definer set search_path=public,pg_temp as $$
declare previous public.profiles; changed public.profiles;
begin
  if not public.is_super_admin() then raise exception 'Super Admin access required' using errcode='42501'; end if;
  select * into previous from public.profiles where id=p_user_id and role='group_admin' for update;
  if not found then raise exception 'Group Admin not found' using errcode='P0002'; end if;
  if p_action='assign' then
    if p_team_id is null or not exists(select 1 from public.teams where id=p_team_id) then raise exception 'Valid team required' using errcode='23503'; end if;
    update public.profiles set team_id=p_team_id where id=p_user_id returning * into changed;
  elsif p_action in ('revoke','suspend') then
    update public.profiles set active=false where id=p_user_id returning * into changed;
  elsif p_action='restore' then
    update public.profiles set active=true where id=p_user_id returning * into changed;
  else raise exception 'Invalid action' using errcode='23514'; end if;
  insert into public.admin_audit_log(actor_id,action,entity_table,entity_id,before_data,after_data)
  values(auth.uid(),'GROUP_ADMIN_'||upper(p_action),'profiles',p_user_id,to_jsonb(previous),to_jsonb(changed));
  return changed;
end;
$$;
create function public.delete_group_admin_profile(p_user_id uuid)
returns void language plpgsql security definer set search_path=public,pg_temp as $$
declare previous public.profiles;
begin
  if not public.is_super_admin() then raise exception 'Super Admin access required' using errcode='42501'; end if;
  select * into previous from public.profiles where id=p_user_id and role='group_admin' for update;
  if not found then raise exception 'Group Admin not found' using errcode='P0002'; end if;
  delete from public.profiles where id=p_user_id;
  insert into public.admin_audit_log(actor_id,action,entity_table,entity_id,before_data)
  values(auth.uid(),'GROUP_ADMIN_DELETE','profiles',p_user_id,to_jsonb(previous));
end;
$$;
revoke all on function public.create_group_admin_profile(uuid,uuid) from public,anon;
revoke all on function public.update_group_admin_profile(uuid,text,uuid) from public,anon;
revoke all on function public.delete_group_admin_profile(uuid) from public,anon;
grant execute on function public.create_group_admin_profile(uuid,uuid) to authenticated;
grant execute on function public.update_group_admin_profile(uuid,text,uuid) to authenticated;
grant execute on function public.delete_group_admin_profile(uuid) to authenticated;
