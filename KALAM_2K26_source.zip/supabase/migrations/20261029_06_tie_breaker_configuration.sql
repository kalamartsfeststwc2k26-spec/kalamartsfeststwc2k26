-- Optional organiser-approved tie-break rules. No rule is active by default.
-- A configured rule compares the count of results at a selected placement.
create table public.standing_tie_breakers (
  id uuid primary key default gen_random_uuid(),
  scope text not null check (scope in ('teams','individuals')),
  division text check (division in ('Mahdhiyya','ATTC')),
  placement integer not null check (placement > 0),
  direction text not null default 'desc' check (direction in ('asc','desc')),
  priority integer not null check (priority >= 0),
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);
create index standing_tie_breaker_priority_idx on public.standing_tie_breakers(scope,division,priority) where is_active;
alter table public.standing_tie_breakers enable row level security;
create policy tie_breakers_public_read on public.standing_tie_breakers for select to anon,authenticated using (is_active or public.is_super_admin());
create policy tie_breakers_super_write on public.standing_tie_breakers for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
revoke all on public.standing_tie_breakers from anon,authenticated;
grant select on public.standing_tie_breakers to anon,authenticated;
grant insert,update,delete on public.standing_tie_breakers to authenticated;
