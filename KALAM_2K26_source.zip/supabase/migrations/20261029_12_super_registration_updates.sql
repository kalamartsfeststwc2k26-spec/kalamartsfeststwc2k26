-- Group Admins still have no registration UPDATE policy; Super Admins can correct any.
create policy registrations_super_update on public.registrations for update to authenticated
  using (public.is_super_admin()) with check (public.is_super_admin());
grant update on public.registrations to authenticated;
