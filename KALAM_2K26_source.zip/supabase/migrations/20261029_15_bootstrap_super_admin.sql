-- Bootstrap only the confirmed Auth account at the organiser-supplied email.
-- Never create a browser-side role assignment or embed a password in a migration.
do $$
declare auth_id uuid;
begin
  select id into strict auth_id from auth.users
    where lower(email) = 'kalamartsfeststwc2k26@gmail.com' and email_confirmed_at is not null;
  if exists (select 1 from public.profiles where id = auth_id and (role <> 'super_admin' or not active or team_id is not null)) then
    raise exception 'Existing profile conflicts with Super Admin bootstrap';
  end if;
  insert into public.profiles (id, role, team_id, active)
    values (auth_id, 'super_admin', null, true)
    on conflict (id) do nothing;
end $$;
