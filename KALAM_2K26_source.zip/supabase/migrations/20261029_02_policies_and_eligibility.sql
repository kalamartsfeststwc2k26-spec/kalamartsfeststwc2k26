-- All client mutation permissions are checked in PostgreSQL; public roster is a narrow view.
create function public.is_super_admin() returns boolean language sql stable security definer set search_path = public, pg_temp as $$
  select exists(select 1 from public.profiles where id = (select auth.uid()) and role = 'super_admin' and active);
$$;
create function public.group_admin_team_id() returns uuid language sql stable security definer set search_path = public, pg_temp as $$
  select team_id from public.profiles where id = (select auth.uid()) and role = 'group_admin' and active limit 1;
$$;
revoke all on function public.is_super_admin() from public, anon;
revoke all on function public.group_admin_team_id() from public, anon;
grant execute on function public.is_super_admin() to anon, authenticated;
grant execute on function public.group_admin_team_id() to authenticated;

create policy teams_public_read on public.teams for select to anon, authenticated using (true);
create policy teams_super_write on public.teams for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
create policy profiles_self_or_super_read on public.profiles for select to authenticated using (id = (select auth.uid()) or public.is_super_admin());
-- No client write policy for profiles: only trusted server service-role code can assign/revoke roles.
create policy students_admin_read on public.students for select to authenticated using (public.is_super_admin() or team_id = public.group_admin_team_id());
create policy students_admin_insert on public.students for insert to authenticated with check (public.is_super_admin() or team_id = public.group_admin_team_id());
create policy students_admin_update on public.students for update to authenticated using (public.is_super_admin() or team_id = public.group_admin_team_id()) with check (public.is_super_admin() or team_id = public.group_admin_team_id());
create policy students_admin_delete on public.students for delete to authenticated using (public.is_super_admin() or team_id = public.group_admin_team_id());
create policy events_public_read on public.events for select to anon, authenticated using (is_published or public.is_super_admin());
create policy events_super_write on public.events for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
create policy registrations_admin_read on public.registrations for select to authenticated using (public.is_super_admin() or exists(select 1 from public.students s where s.id = student_id and s.team_id = public.group_admin_team_id()));
create policy registrations_admin_insert on public.registrations for insert to authenticated with check (public.is_super_admin() or exists(select 1 from public.students s where s.id = student_id and s.team_id = public.group_admin_team_id()));
create policy registrations_admin_delete on public.registrations for delete to authenticated using (public.is_super_admin() or exists(select 1 from public.students s where s.id = student_id and s.team_id = public.group_admin_team_id()));
create policy results_public_read on public.results for select to anon, authenticated using ((status = 'published' and published_at is not null) or public.is_super_admin());
create policy results_super_write on public.results for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
create policy announcements_public_read on public.announcements for select to anon, authenticated using (is_published or public.is_super_admin());
create policy announcements_super_write on public.announcements for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());
create policy committee_public_read on public.committee_members for select to anon, authenticated using (is_published or public.is_super_admin());
create policy committee_super_write on public.committee_members for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

create function public.enforce_registration_eligibility() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare student_division text; event_type text; event_published boolean;
begin
  select division into student_division from public.students where id = new.student_id;
  select competition_type, is_published into event_type, event_published from public.events where id = new.event_id;
  if student_division is null or event_type is null then raise exception 'Student or event not found' using errcode = '23503'; end if;
  if not event_published then raise exception 'Registration is unavailable until the event is published' using errcode = '23514'; end if;
  if event_type = 'ATTC' and student_division <> 'ATTC' then
    raise exception 'Only ATTC students may register for ATTC-category programmes' using errcode = '23514';
  end if;
  new.created_by := auth.uid(); -- Do not trust a client-provided actor.
  return new;
end;
$$;
create trigger registrations_eligibility before insert or update of event_id,student_id,created_by on public.registrations for each row execute function public.enforce_registration_eligibility();
create function public.protect_attc_registrations() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.division <> 'ATTC' and exists (select 1 from public.registrations r join public.events e on e.id=r.event_id where r.student_id=new.id and e.competition_type='ATTC') then
    raise exception 'Cannot change division: student has an ATTC-category registration' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger students_preserve_eligibility before update of division on public.students for each row execute function public.protect_attc_registrations();
create function public.protect_event_eligibility() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
begin
  if new.competition_type = 'ATTC' and exists (select 1 from public.registrations r join public.students s on s.id=r.student_id where r.event_id=new.id and s.division <> 'ATTC') then
    raise exception 'Cannot change to ATTC competition type while non-ATTC students are registered' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger events_preserve_eligibility before update of competition_type on public.events for each row execute function public.protect_event_eligibility();
-- Result owner consistency: individual points also accrue to that student's actual team.
create function public.set_result_team() returns trigger language plpgsql security definer set search_path = public, pg_temp as $$
declare actual_team uuid;
begin
  if new.student_id is not null then
    select team_id into actual_team from public.students where id = new.student_id;
    if actual_team is null then raise exception 'Student not found' using errcode = '23503'; end if;
    if new.team_id is not null and new.team_id <> actual_team then raise exception 'Result team does not match student team' using errcode = '23514'; end if;
    new.team_id := actual_team;
  end if;
  if new.status = 'published' then
    if new.placement is null then raise exception 'Published results require placement' using errcode = '23514'; end if;
    if not exists(select 1 from public.events where id = new.event_id and is_published) then raise exception 'Publish the event before its result' using errcode = '23514'; end if;
    if new.published_at is null then new.published_at := now(); end if;
  end if;
  return new;
end;
$$;
create trigger results_validate before insert or update of student_id,team_id,status,event_id,published_at on public.results for each row execute function public.set_result_team();

create view public.public_event_registrations with (security_barrier = true) as
  select r.id as registration_id, r.event_id, s.name as student_name, t.name as team_name
  from public.registrations r join public.students s on s.id = r.student_id
  join public.teams t on t.id = s.team_id join public.events e on e.id = r.event_id
  where e.is_published;
revoke all on public.profiles, public.teams, public.students, public.events, public.registrations, public.results, public.announcements, public.committee_members from anon, authenticated;
grant select on public.teams, public.events, public.results, public.announcements, public.committee_members to anon, authenticated;
grant select, insert, update, delete on public.students, public.events, public.results, public.teams, public.announcements, public.committee_members to authenticated;
grant select on public.profiles to authenticated;
grant select, insert, delete on public.registrations to authenticated;
revoke all on public.public_event_registrations from public;
grant select on public.public_event_registrations to anon, authenticated;
revoke all on function public.enforce_registration_eligibility() from public, anon, authenticated;
revoke all on function public.protect_attc_registrations() from public, anon, authenticated;
revoke all on function public.protect_event_eligibility() from public, anon, authenticated;
revoke all on function public.set_result_team() from public, anon, authenticated;
