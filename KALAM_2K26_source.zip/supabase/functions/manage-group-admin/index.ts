// Server-only account management: JWT + active Super Admin check on EVERY request.
// Profile mutations use authenticated SECURITY DEFINER RPCs for atomic audit logging.
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Content-Type': 'application/json' };
const reply = (status: number, body: unknown) => new Response(JSON.stringify(body), { status, headers: cors });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
  if (req.method !== 'POST') return reply(405, { error: 'Method not allowed' });
  const token = req.headers.get('Authorization')?.replace(/^Bearer\s+/i, '');
  if (!token) return reply(401, { error: 'Sign in required' });
  const url = Deno.env.get('SUPABASE_URL');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anonKey || !serviceKey) return reply(503, { error: 'Server is not configured' });
  async function api(path: string, method: string, key: string, body?: unknown, bearer = key) {
    const response = await fetch(`${url}${path}`, { method, headers: { apikey: key, Authorization: `Bearer ${bearer}`, 'Content-Type': 'application/json', Prefer: 'return=representation' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    return { ok: response.ok, data: await response.json().catch(() => null) };
  }
  const auth = await api('/auth/v1/user', 'GET', anonKey, undefined, token);
  if (!auth.ok || !auth.data?.id) return reply(401, { error: 'Invalid session' });
  const caller = await api(`/rest/v1/profiles?select=role,active&id=eq.${encodeURIComponent(auth.data.id)}`, 'GET', anonKey, undefined, token);
  if (!caller.ok || caller.data?.[0]?.role !== 'super_admin' || caller.data?.[0]?.active !== true) return reply(403, { error: 'Active Super Admin access required' });
  let input: Record<string, unknown>;
  try { input = await req.json(); } catch { return reply(400, { error: 'Invalid JSON' }); }
  const action = String(input.action || '');
  if (action === 'list') {
    const [profiles, accounts] = await Promise.all([
      api('/rest/v1/profiles?select=id,role,team_id,active,created_at&role=eq.group_admin&order=created_at.desc', 'GET', anonKey, undefined, token),
      api('/auth/v1/admin/users?per_page=1000', 'GET', serviceKey),
    ]);
    if (!profiles.ok || !accounts.ok) return reply(503, { error: 'Could not load admin accounts' });
    const emailById = new Map((accounts.data?.users || []).map((user: {id:string,email:string}) => [user.id, user.email]));
    return reply(200, { users: profiles.data.map((profile: {id:string}) => ({ ...profile, email: emailById.get(profile.id) || null })) });
  }
  const teamId = input.team_id;
  if (action === 'create' || action === 'assign') {
    if (typeof teamId !== 'string' || !/^[0-9a-f-]{36}$/i.test(teamId)) return reply(400, { error: 'Valid team required' });
    const team = await api(`/rest/v1/teams?select=id&id=eq.${encodeURIComponent(teamId)}`, 'GET', anonKey, undefined, token);
    if (!team.ok || !team.data?.length) return reply(400, { error: 'Assigned team does not exist' });
  }
  if (action === 'create') {
    const email = typeof input.email === 'string' ? input.email.trim().toLowerCase() : '';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return reply(400, { error: 'Valid email required' });
    const invited = await api('/auth/v1/invite', 'POST', serviceKey, { email });
    if (!invited.ok || !invited.data?.id) return reply(400, { error: 'Could not invite this email address' });
    const created = await api('/rest/v1/rpc/create_group_admin_profile', 'POST', anonKey, { p_user_id: invited.data.id, p_team_id: teamId }, token);
    if (!created.ok) return reply(400, { error: 'Invite was sent, but admin assignment failed. Do not sign in yet; ask a Super Admin to resolve this account. ' + (created.data?.message || '') });
    return reply(200, { user: { ...created.data, email }, audit_recorded: true });
  }
  const id = input.id;
  if (!['assign','revoke','suspend','restore','delete'].includes(action)) return reply(400, { error: 'Invalid action' });
  if (typeof id !== 'string' || !/^[0-9a-f-]{36}$/i.test(id)) return reply(400, { error: 'Valid Group Admin ID required' });
  const rpcName = action === 'delete' ? 'delete_group_admin_profile' : 'update_group_admin_profile';
  const params = action === 'delete' ? { p_user_id: id } : { p_user_id: id, p_action: action, p_team_id: action === 'assign' ? teamId : null };
  const updated = await api(`/rest/v1/rpc/${rpcName}`, 'POST', anonKey, params, token);
  if (!updated.ok) return reply(400, { error: updated.data?.message || 'Could not update Group Admin' });
  if (action === 'delete') {
    const removed = await api(`/auth/v1/admin/users/${encodeURIComponent(id)}`, 'DELETE', serviceKey);
    if (!removed.ok) return reply(207, { warning: 'Admin access removed and audited, but Auth account deletion needs manual follow-up', id });
    return reply(200, { id, deleted: true, audit_recorded: true });
  }
  return reply(200, { user: updated.data, audit_recorded: true });
});
