# Deploy KALAM 2K26

## Ready-built static ZIP (fastest)

`KALAM_2K26_deploy.zip` contains `index.html`, bundled `assets/`, Netlify's `_redirects`, and Vercel's `vercel.json` at ZIP root. It was built with this project's public Supabase URL and publishable/anon key (normal browser-side configuration). No `.env.local`, service-role key, passwords, or `node_modules` are included. The live Supabase project and its migrations/Edge Function were already set up separately; the ZIP deploys **only the frontend**.

1. Extract the ZIP. On Netlify Drop (https://app.netlify.com/drop), drag the extracted **folder**, not a parent folder; Netlify's docs advise unzipping first. For Vercel Drop (https://vercel.com/drop), drag the extracted static-site folder, or deploy that folder using `vercel --cwd <folder> --prod` after signing in to the CLI. The root `vercel.json` supplies SPA deep-link rewrites; Netlify uses `_redirects`.
2. After the site is live, set your deployed URL as the **Site URL** in Supabase Authentication → URL Configuration; add your real domain and any preview/invite return URLs to Allowed Redirect URLs as needed. Do not broaden database RLS to make the frontend work.
3. Test a direct reload of `/admin/login`, `/events`, and `/teams`, then verify the admin sign-in and public Supabase reads. If Auth email invites are used, test an invite link on the deployed domain.

## Full source ZIP (edit/rebuild)

`KALAM_2K26_source.zip` contains the source, tests, build configuration, deployment configuration, SQL migration history, Edge Function source, documentation, original supplied uploads, **and** the ready-built `dist/` frontend. It excludes local secrets, `.env.local`, credentials, cache/dependencies, and transient outputs. Extract it, set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` from `.env.example` as hosting environment variables (or an untracked `.env.local` for a local build), and run `npm ci && npm run build`. For Git-connected builds, Netlify uses `netlify.toml` (`dist` output); Vercel detects Vite and uses `vercel.json` for deep links. Vite env variables are embedded **at build time**; changing them in the hosting dashboard does not change an already-built static ZIP. Never use a Supabase `service_role` key in `VITE_` variables.

The deployment does not create event, student, result or Group Admin records. The existing Super Admin signs in with their own credentials; none are packaged. Live authenticated browser testing and institutional consent review for public student data remain deployment checks.
