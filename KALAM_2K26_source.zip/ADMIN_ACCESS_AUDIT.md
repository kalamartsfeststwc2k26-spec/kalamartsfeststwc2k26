# Admin CRUD and access audit — 29 October 2026

## Findings and root causes

- The live project has **one active Super Admin**, **no Group Admin accounts**, and **zero students, registrations, and events**. Edit/Delete are row actions, so they cannot appear in empty lists; the Add forms already existed on their authorised admin tabs. The existing Group Admin account invitation/assignment control is available only on the Super Admin tab. There is no evidence that a live account was misclassified, because no Group Admin login exists to exercise.
- The access hook previously set `loading` on **every 30-second background check**, temporarily removing the whole dashboard and its controls. Auth and profile lookup failures could also be misclassified as denied, and the login page duplicated the access rules. The Group Admin dashboard did not distinguish a failed team lookup from a team still loading.
- Student, registration, penalty and Group Admin lists reused one `error` state for both fetch failures and action/validation failures; an action failure could make the record list (and its Edit/Delete buttons) disappear despite successful reads. This was a UI state issue, not a reason to relax RLS.
- Several mutations treated a zero-row PostgREST UPDATE/DELETE as success, even though RLS intentionally returns zero affected rows for a cross-group or removed record. The old UI could falsely say a change was audited without changing anything.
- All shared `ManagedCollection` calls pass `config` and `lookups` correctly. The live schema has `created_at` and `id` for every configured collection; the shared list query's sort columns are valid. Super Admin tabs include Group Admins, students, registrations, results, team deductions, all managed collections, and audit; the Group Admin dashboard intentionally includes only students and registrations.

## Fixes

- One database-backed resolver (`src/lib/adminAccess.js`) for both login and dashboard. Ready requires an active Super Admin profile with no group assignment, or an active Group Admin profile whose team ID resolves to an existing team. Signed-out/no-profile/inactive/inconsistent cases are denied; transport/query errors are errors with retry. Neither email nor client-provided role grants access.
- The hook keeps verified controls present during a routine background refresh, invalidates immediately on a changed login, and ignores stale async responses. The Group Admin dashboard uses the verified team rather than a second uncontrolled fetch.
- Separate list-load errors from action errors; a rejected edit no longer hides an otherwise loaded list. Clarified empty states to explain where Add and row-level Edit/Delete appear. Group assignment changes reset stale student/registration edits.
- Mutation outcomes require exactly one returned row for admin insert/update/delete. Zero-row RLS-filtered writes now show a scope/refresh error, not a false success. Permissions and database policies were **not broadened**.

## Live backend verification

Tested Supabase's actual policies and SECURITY DEFINER functions by switching to `authenticated` with JWT claims for temporary, transaction-rolled-back Group Admin and no-admin Auth fixtures. Also used the existing Super Admin claim for a rolled-back fixture test. Each assertion raises an error if a disallowed action succeeds or an allowed action fails. All suites succeeded; no temporary account, student, registration, event, role change, or audit row was retained. Counts after testing: one Auth user, one profile, zero students, zero registrations and zero events.

- Group Admin: own-group student and registration reads, create/edit/delete **succeeded**. Cross-group student/registration reads were invisible; cross-group insert/edit/delete and moving an owned student/registration into another team were rejected or affected zero rows. ATTC self-verification was rejected.
- No-admin authenticated user: no student or registration reads; student creation and profile-management RPC rejected.
- Role escalation: Group Admin direct `profiles` update and Group Admin profile-management RPC rejected; no-admin RPC rejected.
- Super Admin: read and edit records from another team; event create/edit/delete; create Group Admin profile, change its assigned team, and suspend its role via guarded RPC all succeeded within rolled-back fixtures.
- RLS inspection found `profiles` grants SELECT only to authenticated users (self or Super Admin policy), with no direct UPDATE privilege; student and registration policies constrain Group Admin access to the active profile's assigned team. Event/global write policies require active Super Admin.

## Verification limits

20/20 automated tests and the production build pass. Access-state cases and zero-row mutation handling have direct unit tests. No real signed-in Group Admin exists in the live project, and no browser automation with real Admin credentials was performed; the live role tests use transactional JWT/role simulation against actual database policies. The Super Admin account's password was neither requested nor used. The production build reports a nonblocking chunk-size warning.
