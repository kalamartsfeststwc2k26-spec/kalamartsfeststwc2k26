import { useState } from 'react';
import { Link } from 'react-router-dom';
import { BRAND, LOGO_URL } from '../constants/branding';

export default function BrandMark({ compact = false, inverse = false, showLogo = true, showDot = true }) {
  const [imageFailed, setImageFailed] = useState(false);
  return (
    <Link to="/" className="group inline-flex min-w-0 items-center gap-3 rounded-md focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-burgundy" aria-label="KALAM, back to home">
      {showLogo && <span className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-lg border border-line bg-white sm:h-11 sm:w-11">
        {imageFailed ? <span aria-hidden="true" className="font-extrabold tracking-tight text-burgundy">K</span> : <img src={LOGO_URL} alt="KALAM College Arts Fest 2K26 logo" className="h-full w-full object-contain" onError={() => setImageFailed(true)} />}
      </span>}
      <span className="min-w-0 leading-none">
        <span className={`block text-[1.16rem] font-extrabold tracking-[-.055em] ${inverse ? 'text-white' : 'text-navy'}`}>{BRAND.name}{showDot && <span className="text-burgundy">.</span>}</span>
        {!compact && <span className={`mt-1.5 block whitespace-nowrap text-[.58rem] font-bold uppercase tracking-[.15em] ${inverse ? 'text-white/55' : 'text-muted'}`}>College Arts Fest 2K26</span>}
      </span>
    </Link>
  );
}
