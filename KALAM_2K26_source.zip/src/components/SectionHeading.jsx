export default function SectionHeading({ eyebrow, title, description }) {
  return <div className="mb-8 sm:mb-10">
    {eyebrow && <p className="mb-3 text-[11px] font-bold uppercase tracking-[.17em] text-burgundy">{eyebrow}</p>}
    <h1 className="text-[2.25rem] font-extrabold leading-[1.12] tracking-[-.04em] text-navy sm:text-[3rem]">{title}</h1>
    {description && <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted sm:text-base">{description}</p>}
  </div>;
}
