import { useCallback, useEffect, useState } from 'react';
import { BRAND, LOGO_URL } from '../constants/branding';

const SPLASH_KEY = 'kalam:splash-seen:v1';
function hasSeenSplash() {
  try { return window.sessionStorage.getItem(SPLASH_KEY) === '1'; } catch { return false; }
}
function markSeen() {
  try { window.sessionStorage.setItem(SPLASH_KEY, '1'); } catch { /* Storage may be disabled. */ }
}

export default function FirstVisitSplash({ children }) {
  // Never intercept a direct link to another route.
  const [show, setShow] = useState(() => window.location.pathname === '/' && !hasSeenSplash());
  const [phase, setPhase] = useState('loading');
  const [failed, setFailed] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(() => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false);
  const finish = useCallback(() => { markSeen(); setShow(false); }, []);

  useEffect(() => {
    if (!show) return;
    const media = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    const change = () => setReducedMotion(media.matches);
    media?.addEventListener?.('change', change);
    return () => media?.removeEventListener?.('change', change);
  }, [show]);

  useEffect(() => {
    if (!show) return;
    const timeout = window.setTimeout(() => { setFailed(true); setPhase('failed'); }, 5000);
    return () => window.clearTimeout(timeout);
  }, [show]);

  useEffect(() => {
    if (!show || phase !== 'logo') return;
    const reveal = window.setTimeout(() => setPhase('words'), reducedMotion ? 100 : 1350);
    return () => window.clearTimeout(reveal);
  }, [show, phase, reducedMotion]);
  useEffect(() => {
    if (!show || phase !== 'words') return;
    const continueTimer = window.setTimeout(finish, reducedMotion ? 800 : 1400);
    return () => window.clearTimeout(continueTimer);
  }, [show, phase, reducedMotion, finish]);
  useEffect(() => {
    if (!show || phase !== 'failed') return;
    const continueTimer = window.setTimeout(finish, 1200);
    return () => window.clearTimeout(continueTimer);
  }, [show, phase, finish]);

  if (!show) return children;
  return <main className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-navy px-6 py-16 text-center text-white" aria-label="KALAM festival welcome">
    <button type="button" onClick={finish} className="absolute right-5 top-5 rounded-full border border-white/30 px-4 py-2 text-xs font-semibold text-white hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white sm:right-8 sm:top-8">{failed ? 'Continue to site' : 'Skip intro'}</button>
    <div className="flex w-full max-w-md flex-col items-center">
      <div className={`grid h-48 w-48 place-items-center overflow-hidden rounded-[1.75rem] bg-white p-3 shadow-raised transition-all ease-out sm:h-56 sm:w-56 ${phase === 'loading' ? 'scale-[.6] opacity-0' : 'scale-100 opacity-100'}`} style={{ transitionDuration: reducedMotion ? '0ms' : '1250ms' }}>
        {failed ? <span className="text-7xl font-extrabold tracking-[-.09em] text-burgundy" aria-label="KALAM">K</span> : <img src={LOGO_URL} alt="KALAM College Arts Fest 2K26 logo" className="h-full w-full rounded-2xl object-contain" onLoad={() => setPhase(current => current === 'loading' ? 'logo' : current)} onError={() => { setFailed(true); setPhase('failed'); }} />}
      </div>
      <div className={`mt-10 transition-all duration-500 ${phase === 'words' || phase === 'failed' ? 'translate-y-0 opacity-100' : 'translate-y-3 opacity-0'}`}>
        <p className="text-[11px] font-bold uppercase tracking-[.22em] text-white/60">Shihab Thangal Women’s College</p>
        <h1 className="mt-3 text-5xl font-extrabold tracking-[-.07em] sm:text-6xl">KALAM<span className="text-gold">.</span></h1>
        <p className="mt-2 text-sm font-semibold tracking-[.09em] text-white/85">COLLEGE ARTS FEST 2K26</p>
        <p lang="ml" className="mt-5 text-lg font-medium leading-relaxed text-white/85">{BRAND.tagline}</p>
      </div>
      {phase === 'loading' && <span className="sr-only" role="status">Loading festival welcome</span>}
    </div>
  </main>;
}
