import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { ArrowUpRight, ChevronDown, Menu, Search, X } from 'lucide-react';
import BrandMark from '../components/BrandMark';
import ConnectionNotice from '../components/ConnectionNotice';
import { BRAND } from '../constants/branding';
import { primaryNav, secondaryNav } from '../constants/navigation';

const desktopLinks = primaryNav.filter(({ to }) => ['/', '/events', '/results', '/leaderboard', '/teams'].includes(to));
const moreLinks = [{ label: 'Schedule', to: '/schedule' }, ...secondaryNav];
const desktopClass = ({ isActive }) => `relative inline-flex h-9 items-center rounded-lg px-3 text-[13px] font-semibold transition-colors duration-fast focus-visible:outline focus-visible:outline-2 focus-visible:outline-burgundy ${isActive ? 'bg-burgundy text-white shadow-soft' : 'text-muted hover:bg-page hover:text-navy'}`;
const mobileClass = ({ isActive }) => `flex items-center justify-between border-b border-line px-1 py-3.5 text-[15px] font-semibold transition-colors duration-fast ${isActive ? 'text-burgundy' : 'text-navy hover:text-burgundy'}`;

export default function AppShell() {
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const menuButton = useRef(null);
  const firstRoute = useRef(true);
  useEffect(() => { setMenuOpen(false); window.scrollTo(0, 0); if (!firstRoute.current) document.getElementById('main-content')?.focus(); firstRoute.current = false; }, [location.pathname]);
  useEffect(() => {
    if (!menuOpen) return;
    const close = (event) => { if (event.key === 'Escape') { setMenuOpen(false); menuButton.current?.focus(); } };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [menuOpen]);
  return <div className="flex min-h-screen flex-col bg-page text-ink">
    <a href="#main-content" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-navy">Skip to content</a>
    <ConnectionNotice />
    <header className="relative z-40 border-b border-line bg-white">
      <div className="mx-auto flex h-[68px] max-w-[1240px] items-center justify-between gap-4 px-5 sm:px-8 lg:px-10">
        <BrandMark showLogo={false} showDot={false} />
        <nav aria-label="Primary navigation" className="hidden items-center gap-4 lg:flex xl:gap-6">
          {desktopLinks.map(item => <NavLink key={item.to} to={item.to} end={item.to === '/'} className={desktopClass}>{item.label}</NavLink>)}
          <details className="group relative" onKeyDown={e => { if (e.key === 'Escape') e.currentTarget.open = false; }}><summary className="flex h-9 cursor-pointer list-none items-center gap-1 rounded-lg px-3 text-[13px] font-semibold text-muted marker:hidden hover:text-navy focus-visible:rounded-md focus-visible:outline focus-visible:outline-2 focus-visible:outline-burgundy [&::-webkit-details-marker]:hidden">More <ChevronDown size={14} className="transition-transform group-open:rotate-180" aria-hidden="true" /></summary><div className="absolute right-0 top-[calc(100%+12px)] z-50 w-48 rounded-xl border border-line bg-white p-2 shadow-raised">{moreLinks.map(item => <NavLink key={item.to} to={item.to} onClick={e => { e.currentTarget.closest('details').open = false; }} className={({ isActive }) => `block rounded-lg px-3 py-2.5 text-sm font-semibold ${isActive ? 'bg-page text-burgundy' : 'text-navy hover:bg-page'}`}>{item.label}</NavLink>)}</div></details>
        </nav>
        <div className="flex items-center gap-1 sm:gap-3">
          <Link to="/search" aria-label="Search" className="grid h-10 w-10 place-items-center rounded-full text-navy transition-colors duration-fast hover:bg-page focus-visible:outline focus-visible:outline-2 focus-visible:outline-burgundy"><Search size={19} aria-hidden="true" /></Link>
          <span aria-hidden="true" className="hidden h-5 w-px bg-line sm:block" />
          <Link to="/admin/login" className="hidden items-center gap-1.5 rounded-lg bg-navy px-4 py-2.5 text-xs font-bold text-white transition-colors duration-fast hover:bg-navy-deep focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-burgundy sm:inline-flex">Admin <ArrowUpRight size={14} aria-hidden="true" /></Link>
          <button ref={menuButton} type="button" aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen(v => !v)} className="grid h-10 w-10 place-items-center rounded-full text-navy transition-colors duration-fast hover:bg-page focus-visible:outline focus-visible:outline-2 focus-visible:outline-burgundy lg:hidden">{menuOpen ? <X size={22} aria-hidden="true" /> : <Menu size={22} aria-hidden="true" />}</button>
        </div>
      </div>
      {menuOpen && <nav id="mobile-navigation" aria-label="Mobile navigation" className="absolute inset-x-0 top-full max-h-[calc(100dvh-68px)] overflow-y-auto border-t border-line bg-white px-5 pb-7 pt-2 shadow-raised sm:px-8 lg:hidden"><div className="mx-auto grid max-w-[1160px] sm:grid-cols-2 sm:gap-x-10">{[...primaryNav, ...secondaryNav].map(item => <NavLink key={item.to} to={item.to} end={item.to === '/'} className={mobileClass}>{item.label}<ArrowUpRight size={14} aria-hidden="true" /></NavLink>)}<NavLink to="/search" className={mobileClass}>Search <ArrowUpRight size={14} aria-hidden="true" /></NavLink><NavLink to="/admin/login" className={mobileClass}>Admin sign in <ArrowUpRight size={14} aria-hidden="true" /></NavLink></div></nav>}
    </header>
    <main id="main-content" className="flex-1" tabIndex="-1"><Outlet /></main>
    <footer className="bg-navy-deep text-white">
      <div className="mx-auto grid max-w-[1240px] gap-6 px-5 py-7 sm:px-8 lg:grid-cols-[1fr_auto] lg:gap-10 lg:px-10 lg:py-8">
        <div><BrandMark inverse compact /><p className="mt-3 max-w-sm text-sm leading-relaxed text-white/60">{BRAND.college}<br />{BRAND.location}</p><p lang="ml" className="mt-2 text-sm text-white/80">{BRAND.tagline}</p></div>
        <nav aria-label="Footer navigation" className="grid grid-cols-2 content-start gap-x-10 gap-y-2.5 text-sm font-medium text-white/70 sm:gap-x-16">{secondaryNav.map(item => <Link key={item.to} to={item.to} className="hover:text-white focus-visible:rounded focus-visible:outline focus-visible:outline-2 focus-visible:outline-burgundy">{item.label}</Link>)}</nav>
      </div>
      <div className="border-t border-white/10"><div className="mx-auto flex max-w-[1240px] flex-wrap justify-between gap-2 px-5 py-3 text-xs text-white/50 sm:px-8 lg:px-10"><span>© 2026 KALAM · STWC</span><span>Made for the arts. Made for everyone.</span></div></div>
    </footer>
  </div>;
}
