import { friendlyQueryError } from '../lib/friendlyError';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell, CalendarDays, ChevronRight, Clock3, ListFilter, Trophy, Users, Medal, RefreshCw } from 'lucide-react';
import { BRAND, LOGO_URL } from '../constants/branding';
import { HOME_SCHEMA } from '../lib/homeDashboard';
import { eventStatus } from '../lib/eventUtils';
import { useHomeDashboard } from '../lib/useHomeDashboard';

function Panel({ title, to, action = 'View all', Icon, children }) {
  return <section className="overflow-hidden rounded-panel border border-line bg-white shadow-soft">
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-5 sm:px-7">
      <h2 className="flex items-center gap-2.5 text-[1.1rem] font-bold tracking-[-.025em] text-navy sm:text-[1.22rem]"><Icon size={18} strokeWidth={1.8} className="shrink-0 text-burgundy" aria-hidden="true" />{title}</h2>
      <Link to={to} className="inline-flex items-center gap-1 text-xs font-bold text-burgundy hover:underline focus-visible:rounded focus-visible:outline focus-visible:outline-2 focus-visible:outline-burgundy">{action}<ChevronRight size={14} aria-hidden="true" /></Link>
    </div>
    <div className="p-5 sm:p-7">{children}</div>
  </section>;
}
function QuietState({ children }) {
  return <div className="rounded-xl border border-line bg-page px-5 py-6 text-center text-sm leading-relaxed text-muted">{children}</div>;
}
function PanelState({ status, empty }) {
  if (status === 'loading') return <div role="status" className="rounded-xl bg-page px-5 py-6 text-center text-sm text-muted">Loading the latest information…<div aria-hidden="true" className="mt-4 space-y-2"><div className="h-3 w-4/5 rounded-full bg-white" /><div className="h-3 w-2/3 rounded-full bg-white" /></div></div>;
  if (status === 'offline') return <div role="alert" className="rounded-xl bg-page px-5 py-6 text-center text-sm text-muted">You are offline. Reconnect to see current information.</div>;
  if (status === 'error') return <div role="alert" className="rounded-xl bg-page px-5 py-6 text-center text-sm text-muted">Live information is temporarily unavailable.</div>;
  return <QuietState>{empty}</QuietState>;
}
function formatTime(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', hour: 'numeric', minute: '2-digit' }).format(date);
}
function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : new Intl.DateTimeFormat('en-IN', { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short' }).format(date);
}
function EventList({ items, status, empty }) {
  if (status !== 'ready' || !items?.length) return <PanelState status={status} empty={empty} />;
  const fields = HOME_SCHEMA.events;
  return <ul className="divide-y divide-line rounded-xl border border-line bg-white">{items.map(event => <li key={event[fields.id]}><Link to={`/events/${encodeURIComponent(event[fields.id])}`} className="flex items-center gap-3 px-4 py-3.5 text-sm hover:bg-page focus-visible:outline focus-visible:outline-2 focus-visible:outline-burgundy"><span className="min-w-0 flex-1 font-semibold text-navy">{event[fields.title]}</span><span className="shrink-0 text-xs tabular-nums text-muted">{eventStatus(event) === 'Schedule TBA' ? 'Schedule TBA' : formatTime(event[fields.startsAt])}</span><ChevronRight size={15} className="shrink-0 text-burgundy" aria-hidden="true" /></Link></li>)}</ul>;
}
function Standings({ items, status, empty }) {
  if (status !== 'ready' || !items?.length) return <PanelState status={status} empty={empty} />;
  return <ol className="divide-y divide-line">{items.map(item => <li key={item.id} className="flex items-center gap-3 py-3 text-sm first:pt-0 last:pb-0"><span className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg text-xs font-bold tabular-nums ${item.rank === 1 ? 'bg-page text-navy ring-1 ring-inset ring-gold' : 'bg-page text-navy'}`} aria-label={`Rank ${item.rank}`}>{item.rank}</span><span className="min-w-0 flex-1 break-words font-semibold text-navy">{item.name}<span className="block text-xs font-medium text-muted">Rank {item.rank}{item.deductionPoints > 0 ? ` · Minus ${item.deductionPoints.toLocaleString('en-IN')} pts` : ''}</span></span><span className="whitespace-nowrap font-bold tabular-nums text-navy">{item.points.toLocaleString('en-IN')} <span className="text-xs font-medium text-muted">pts</span></span></li>)}</ol>;
}
export default function HomePage() {
  const [imageFailed, setImageFailed] = useState(false);
  const { status, data, error, refresh } = useHomeDashboard();
  const a = HOME_SCHEMA?.announcements;
  const r = HOME_SCHEMA?.results;
  return <div className="mx-auto max-w-[1240px] px-5 pb-24 pt-8 sm:px-8 sm:pt-10 lg:px-10">
    <section className="relative overflow-hidden rounded-panel border border-line bg-white shadow-soft">
      <div className="flex flex-col-reverse justify-between gap-6 px-6 py-8 sm:px-9 sm:py-9 md:flex-row md:items-center md:gap-10 lg:px-11 lg:py-11">
        <div className="min-w-0"><p className="text-[11px] font-bold uppercase tracking-[.18em] text-burgundy">{BRAND.college} presents</p><h1 className="mt-3 text-[clamp(2.8rem,6vw,5rem)] font-extrabold leading-[1] tracking-[-.06em] text-navy">KALAM <span className="text-burgundy">2K26</span></h1><p className="mt-3 text-sm font-semibold uppercase tracking-[.13em] text-muted">College Arts Fest</p><p lang="ml" className="mt-6 text-lg font-semibold leading-relaxed text-navy sm:text-xl">{BRAND.tagline}</p><p className="mt-2 text-sm text-muted">STWC · Chundampatta, Palakkad</p></div>
        <div className="mx-auto flex w-full max-w-[400px] shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-line bg-white p-3 shadow-soft sm:max-w-[500px] md:mx-0 md:w-[40%] lg:w-[46%]">{imageFailed ? <span className="text-7xl font-extrabold text-burgundy" aria-label="KALAM logo fallback">K</span> : <img src={LOGO_URL} onError={() => setImageFailed(true)} alt="KALAM College Arts Fest 2K26 logo" className="block h-auto w-full object-contain" loading="eager" decoding="async" fetchPriority="high" />}</div>
      </div>
    </section>
    {status === 'error' && <div role="alert" className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-white px-5 py-4 text-sm text-navy"><span>{friendlyQueryError(error, 'festival data')}</span><button type="button" onClick={refresh} className="inline-flex items-center gap-2 font-bold text-burgundy hover:underline"><RefreshCw size={14} aria-hidden="true" />Retry</button></div>}
    <div className="mt-7 grid gap-6 lg:grid-cols-[minmax(0,1.85fr)_minmax(290px,1fr)] lg:items-start">
      <div className="grid gap-6">
        <Panel title="Festival timeline" to="/schedule" action="View schedule" Icon={CalendarDays}>
          <div className="space-y-5"><div><p className="mb-2.5 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.15em] text-burgundy"><span aria-hidden="true" className={`h-1.5 w-1.5 rounded-full ${status === 'ready' && data?.timeline.live.length ? 'bg-[var(--color-live)]' : 'bg-navy/40'}`} />Live now</p><EventList items={data?.timeline.live} status={status} empty="No events are currently live." /></div><div><p className="mb-2.5 flex items-center gap-2 text-[11px] font-bold uppercase tracking-[.15em] text-muted"><Clock3 size={13} aria-hidden="true" />Coming next</p><EventList items={data?.timeline.next} status={status} empty="No upcoming events with confirmed start and end times." /></div>{status === 'ready' && Boolean(data?.timeline.tba.length) && <div><p className="mb-2.5 text-[11px] font-bold uppercase tracking-[.15em] text-muted">Schedule TBA</p><EventList items={data.timeline.tba} status={status} empty="No events awaiting a schedule." /></div>}</div>
        </Panel>
        <Panel title="Latest results" to="/results" Icon={Trophy}>
          {status !== 'ready' || !data?.results.length ? <PanelState status={status} empty="No published results yet." /> : <ul className="divide-y divide-line">{data.results.map(row => <li key={row[r.id]} className="flex flex-wrap items-center gap-x-4 gap-y-1.5 py-3 first:pt-0 last:pb-0"><div className="min-w-0 flex-1"><p className="break-words text-sm font-semibold text-navy">{row.eventName || 'Event'}</p><p className="mt-0.5 text-xs text-muted">{row[r.placement] != null ? `Place ${row[r.placement]} · ` : ''}{row.studentName || row.teamName || 'Participant not listed'}{row[r.grade] ? ` · Grade ${row[r.grade]}` : ''}</p></div><span className="whitespace-nowrap text-sm font-bold tabular-nums text-navy">{Number(row[r.points]).toLocaleString('en-IN')} <span className="text-xs font-medium text-muted">pts</span></span></li>)}</ul>}
        </Panel>
      </div>
      <div className="grid gap-6">
        <Panel title="Latest announcements" to="/announcements" Icon={Bell}>
          {status !== 'ready' || !data?.announcements.length ? <PanelState status={status} empty="No announcements have been published." /> : <ul className="divide-y divide-line">{data.announcements.map(item => <li key={item[a.id]} className="py-3 first:pt-0 last:pb-0"><p className="text-xs font-semibold text-muted">{formatDate(item[a.createdAt])}</p><p className="mt-1 text-sm font-bold text-navy">{item[a.title]}</p><p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted">{item[a.body]}</p></li>)}</ul>}
        </Panel>
        <Panel title="Top teams" to="/leaderboard" action="Full rankings" Icon={Trophy}><Standings items={data?.teams} status={status} empty="No published team points yet." /></Panel>
        <Panel title="Top individuals" to="/leaderboard" action="Full rankings" Icon={Medal}><Standings items={data?.individuals} status={status} empty="No published individual points yet." /></Panel>
        <Panel title="Explore KALAM" to="/events" action="All events" Icon={ListFilter}>
          <nav aria-label="Explore festival sections" className="-my-2">{[{ to: '/events', label: 'Events', Icon: CalendarDays }, { to: '/teams', label: 'Teams', Icon: Users }, { to: '/rules', label: 'Participation rules', Icon: ListFilter }].map(({ to, label, Icon }) => <Link key={to} to={to} className="flex items-center gap-3 border-b border-line py-3.5 text-sm font-semibold text-navy last:border-0 hover:text-burgundy focus-visible:outline focus-visible:outline-2 focus-visible:outline-burgundy"><Icon size={16} className="text-burgundy" aria-hidden="true" /><span className="flex-1">{label}</span><ChevronRight size={15} aria-hidden="true" /></Link>)}</nav>
        </Panel>
      </div>
    </div>
  </div>;
}
