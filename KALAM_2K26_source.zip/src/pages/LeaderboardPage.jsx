import { friendlyQueryError } from '../lib/friendlyError';
import { useMemo, useState } from 'react';
import { Medal, RefreshCw, Trophy } from 'lucide-react';
import DataState from '../components/DataState';
import IdentityImage from '../components/IdentityImage';
import SectionHeading from '../components/SectionHeading';
import { fetchStandingsData } from '../lib/publicRecords';
import { formatPoints, makeIndividualStandings, makeTeamStandings } from '../lib/rankings';
import { usePublicData } from '../lib/usePublicData';

function StandingsList({ rows, mode }) {
  return <ol className="divide-y divide-line">{rows.map(row => <li key={row.id} className="flex items-center gap-3 py-4 first:pt-0 last:pb-0 sm:gap-5">
    <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl text-sm font-extrabold tabular-nums ${row.rank === 1 ? 'bg-page text-navy ring-1 ring-inset ring-gold' : 'bg-page text-navy'}`} aria-label={`Rank ${row.rank}`}>{row.rank}</span>
    {mode === 'teams' && <IdentityImage src={row.logo_url} name={row.name} className="h-11 w-11" />}
    <div className="min-w-0 flex-1"><p className="break-words text-sm font-bold text-navy sm:text-base">{row.name}</p><p className="mt-0.5 text-xs font-semibold text-muted">{row.tied ? `Shared rank ${row.rank}` : `Rank ${row.rank}`}{mode === 'individuals' && row.teamName ? ` · ${row.teamName}` : ''}{mode === 'teams' && row.deductionPoints > 0 ? ` · Earned ${formatPoints(row.earnedPoints)} − minus ${formatPoints(row.deductionPoints)} points` : ''}</p></div>
    <span className="whitespace-nowrap text-right text-lg font-extrabold tabular-nums text-navy">{formatPoints(row.points)} <span className="text-xs font-medium text-muted">pts</span></span>
  </li>)}</ol>;
}
export default function LeaderboardPage() {
  const { status, data, error, refresh } = usePublicData(fetchStandingsData, 'leaderboard');
  const [mode, setMode] = useState('teams');
  const rules = useMemo(() => status !== 'ready' ? [] : data.tieBreakers.filter(rule => rule.scope === mode && (!rule.division || rule.division === 'Mahdhiyya')), [status, data, mode]);
  const hasScoredResults = status === 'ready' && (data.results.some(row => Number(row.points) > 0 && (mode === 'teams' ? row.team_id != null : row.student_id != null)) || (mode === 'teams' && data.penalties.length > 0));
  const rows = useMemo(() => status !== 'ready' || !hasScoredResults ? [] : mode === 'teams' ? makeTeamStandings(data.teams, data.results, rules, data.penalties) : makeIndividualStandings(data.results, rules), [status, data, mode, rules, hasScoredResults]);
  const titles = useMemo(() => status !== 'ready' ? [] : data.titles, [status, data]);
  const groups = useMemo(() => Object.groupBy ? Object.groupBy(titles, title => title.title_type) : titles.reduce((map, title) => { (map[title.title_type] ||= []).push(title); return map; }, {}), [titles]);
  return <div className="mx-auto max-w-[1120px] px-5 pb-24 pt-10 sm:px-8 sm:pt-14 lg:px-10">
    <div className="flex flex-wrap items-end justify-between gap-4"><SectionHeading eyebrow="Standings / KALAM 2K26" title="Leaderboard" description="Team totals subtract Super Admin-applied minus marks; individual points are unchanged. Equal totals share a rank unless an approved tie-break rule applies." /><button onClick={refresh} className="mb-8 inline-flex items-center gap-2 rounded-full border border-line bg-white px-4 py-2.5 text-xs font-bold text-navy hover:bg-page"><RefreshCw size={14} aria-hidden="true" />Refresh</button></div>
    <div className="mb-6 flex flex-wrap items-end justify-between gap-5 rounded-panel border border-line bg-white p-5 shadow-soft sm:p-6"><div role="group" aria-label="Leaderboard view" className="flex rounded-xl bg-page p-1"><button aria-pressed={mode === 'teams'} onClick={() => setMode('teams')} className={`rounded-lg px-4 py-2.5 text-sm font-bold transition-colors ${mode === 'teams' ? 'bg-navy text-white' : 'text-muted hover:text-navy'}`}>Groups / Teams</button><button aria-pressed={mode === 'individuals'} onClick={() => setMode('individuals')} className={`rounded-lg px-4 py-2.5 text-sm font-bold transition-colors ${mode === 'individuals' ? 'bg-navy text-white' : 'text-muted hover:text-navy'}`}>Individuals</button></div><span className="text-xs font-semibold text-muted">Mahdhiyya division</span></div>
    {status === 'loading' ? <DataState status="loading" /> : status === 'offline' ? <DataState status="offline" onRetry={refresh} /> : status === 'error' ? <DataState status="error" description={friendlyQueryError(error)} onRetry={refresh} /> : <>
      <section className="rounded-panel border border-line bg-white p-5 shadow-soft sm:p-8"><div className="mb-5 flex items-center gap-2 border-b border-line pb-5"><Trophy size={19} className="text-burgundy" aria-hidden="true" /><h2 className="text-xl font-bold text-navy">{mode === 'teams' ? 'Group / Team standings' : 'Individual standings'}</h2></div>{rows.length ? <StandingsList rows={rows} mode={mode} /> : <p className="rounded-xl bg-page px-5 py-8 text-center text-sm text-muted">{mode === 'teams' && !data.teams.length ? 'No teams have been added yet.' : `No published ${mode === 'teams' ? 'team' : 'individual'} points yet.`}</p>}</section>
      <section className="mt-7 rounded-panel border border-line bg-white p-5 shadow-soft sm:p-8"><div className="mb-5 flex items-center gap-2 border-b border-line pb-5"><Medal size={19} className="text-burgundy" aria-hidden="true" /><h2 className="text-xl font-bold text-navy">Special Titles</h2></div>{!titles.length ? <p className="rounded-xl bg-page px-5 py-8 text-center text-sm text-muted">No special titles published yet.</p> : <div className="grid gap-6 sm:grid-cols-2">{Object.entries(groups).map(([type, awards]) => <div key={type} className="rounded-xl border border-line p-5"><h3 className="text-sm font-bold uppercase tracking-[.09em] text-burgundy">{type}</h3><ul className="mt-3 divide-y divide-line">{awards.map(award => <li key={award.id} className="py-3 first:pt-0 last:pb-0"><p className="text-sm font-bold text-navy">{award.award_title}</p><p className="mt-1 text-sm text-muted">{award.recipient_name} <span className="text-xs">· {award.recipient_kind}{award.division ? ` · ${award.division}` : ''}</span></p></li>)}</ul></div>)}</div>}</section>
    </>}
  </div>;
}
