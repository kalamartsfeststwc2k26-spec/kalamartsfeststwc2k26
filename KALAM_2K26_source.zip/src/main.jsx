import React from 'react';
import ReactDOM from 'react-dom/client';
import AppRoutes from './routes/AppRoutes';
import FirstVisitSplash from './components/FirstVisitSplash';
import './styles.css';

ReactDOM.createRoot(document.getElementById('root')).render(<React.StrictMode><FirstVisitSplash><AppRoutes /></FirstVisitSplash></React.StrictMode>);
